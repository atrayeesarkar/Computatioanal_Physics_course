global a % assigning a as global variable so that a is not required as a parameter for the function deriv
a = input('enter value of a: \n'); % user input toplot for both a<0 and a>0
[t,result]=ode45(@deriv,[0,200],.00001);

figure

plot(t,abs(result))
xlabel('time')
ylabel('r')
grid on


function f=deriv(t,X)
    global a
    f=a*X-X*X*X; 
end


%---------Comment-----------%

% For a < 0, the hopf model has only one equilibrium point at (0,0) and it is a inward spiral. So, for a<0, r should mootonically decrease and converge to 0. That is what I got for a = -0.1. But for a <= -0.5 r is oscillating and becoming -ve which is not physically meaningful. 
% For a >0, we have stable limit cycle with radius sqrt(a) and r should converge to sqrt(a). That is what is observed.    
%     