M = zeros(50,50); % initializing M as 50x50 matrix with all zero element
for i = 1:50
    for j = 1:50
        if abs(i-j)<3
            M(i,j) = 1; % we do not need the else statement here as we already initialized M as zero matrix  
        end
    end 
end 
b0 = ones(50,1);
b1 = M*b0/norm(b0);
tolerance = 10^(-6)*norm(b1);
error = norm(b1-b0);
count = 1;
while error >=tolerance
    b0 = b1;
    b1 = M*b0/norm(b0);
    tolerance = 10^(-6)*norm(b1);
    error = norm(b1-b0);
    count = count+1;
end
[V,L] = eig(M);% V is eigen vector  matrix, L is weigen value matrix 
L_row = b0'*L; % row matrix containing of eigen_values
[lambda_max,I] = max(L_row); % to find max eigen value
bkmax = b1;
if norm(M*bkmax-lambda_max*bkmax) < 10^-4 % tolerance
    disp("M*bkmax is nearly same as lambda_max*bkmax")
end 