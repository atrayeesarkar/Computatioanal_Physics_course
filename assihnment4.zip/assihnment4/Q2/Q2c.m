
M = zeros(50,50); % initializing M as 50x50 matrix with all zero element
for i = 1:50
    for j = 1:50
        if abs(i-j)<3
            M(i,j) = 1; % we do not need the else statement here as we already initialized M as zero matrix  
        end
    end 
end 
b0 = ones(50,1);

[V,L] = eig(M);
L_row = b0'*L; % row matrix containing of eigen_values
[lambda_max,I] = max(L_row);
V_max = V(:,I);

disp('V_max is:' )
disp (V_max)
disp('lamda_max is:' )
disp(lambda_max)