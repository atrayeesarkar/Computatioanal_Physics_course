function F=deriv(x,t,param)
    F=[x(2),-param*x(1)];
end