% neutrn - Program to solve the neutron diffusion equation 
% using the Forward Time Centered Space (FTCS) scheme.
clear;  % Clear memory and print header

%* Initialize parameters (time step, grid points, etc.).
tau = input('Enter time step: ');
N = input('Enter the number of grid points: ');
N=N+2;
L = input('Enter system length: ');  
% The system extends from x=-L/2 to x=L/2
h = L/(N-1);  % Grid size
D = input('Enter d value 1 or 10 or 100: ');   % Diffusion coefficient
C = 1.;   % Generation rate
coeff = D*tau/h^2;
coeff2 = C*tau;
if( coeff < 0.5 )
  disp('Solution is expected to be stable');
else
  disp('WARNING: Solution is expected to be unstable');
end

%* Set initial and boundary conditions.
nn = zeros(N,1);        % Initialize density to zero at all points
nn_new = zeros(N,1);    % Initialize temporary array used by FTCS
nn(round(N/2)) = 1/h;   % Initial cond. is delta function in center
%% The boundary conditions are nn(1) = nn(N) = 0

%* Set up loop and plot variables.
xplot = (0:N-3)*h - L/2;   % Record the x scale for plots
iplot = 1;                 % Counter used to count plots
nstep = 300; % maximum number of iterations
nplots = 100;               % Number of snapshots (plots) to take
plot_step = nstep/nplots;  % Number of time steps between plots

%* Loop over the desired number of time steps.
nnplot = zeros(N-2,nplots);
tplot = zeros(1,nplots);
for istep=1:nstep  %% MAIN LOOP %%
   
  %* Compute the new density using FTCS scheme.
  nn_new(2:(N-1)) = nn(2:(N-1)) + ...
      coeff*(nn(3:N) + nn(1:(N-2)) - 2*nn(2:(N-1))) + ...
	   coeff2*nn(2:(N-1));
   nn_new(1)=nn_new(3);
   nn_new(N) = nn_new(N-2);
  nn = nn_new;        % Reset temperature to new values
  
  %* Periodically record the density for plotting.
  if( rem(istep,plot_step) < 1 )   % Every plot_step steps
    nnplot(:,iplot) = nn(2:N-1);       % record nn(i) for plotting
    tplot(iplot) = istep*tau;      % Record time for plots
    nAve(iplot) = mean(nn);        % Record average density 
	 iplot = iplot+1;
	 fprintf('Finished %g of %g steps\n',istep,nstep);
  end
end

%* Plot density versus x and t as a 3D-surface plot
figure(1); clf;
mesh(tplot,xplot,nnplot);
xlabel('Time');  ylabel('x');  zlabel('n(x,t)');
title('Neutron diffusion');

%* Plot average neutron density versus time
figure(2); clf;
plot(tplot,nAve,'*');
xlabel('Time'); ylabel('Average density');
title(['L = ',num2str(L),'  (L_c = \pi)']);