% neutrn - Program to solve the neutron diffusion equation 
% using the  the Crank-Nicolson scheme
clear;  % Clear memory and print header

%* Initialize parameters (time step, grid points, etc.).
tau = input('Enter time step: ');
N = input('Enter the number of grid points: ');
N=N+2;
L = 1;  
% The system extends from x=-L/2 to x=L/2
h = L/(N-1);  % Grid size
x = h*(0:N-1) - L/2;  % Coordinates  of grid points
D = input('Enter D value either 1 or 10 or 100');;   % Diffusion coefficient
C = 1.;   % Generation rate
coeff = D*tau/h^2;
coeff2 = C*tau;
if( coeff < 0.5 )
  disp('Solution is expected to be stable');
else
  disp('WARNING: Solution is expected to be unstable');
end
%* Set up the Hamiltonian operator matrix
ham = zeros(N);  % Set all elements to zero

for i=2:(N-1)
  ham(i,i-1) = coeff;
  ham(i,i) = -2*coeff+coeff2;  % Set interior rows
  ham(i,i+1) = coeff;
end
% First and last virtual rows for reflective boundary conditions
% ham(1,N) = coeff;   ham(1,1) = -2*coeff+coeff2; ham(1,2) = coeff;
% ham(N,N-1) = coeff; ham(N,N) = -2*coeff+coeff2; ham(N,1) = coeff;
ham(:,1) = ham(:,3);
ham(:,N) = ham(:,N-2);
ham(1,:) = ham(3,:);
ham(N,:) = ham(N-2,:);
%* Compute the Crank-Nicolson matrix
dCN = ( inv(eye(N) + ham) * ...
             (eye(N) - ham) );
 
 %* Initialize density 
psi = zeros(N,1);
psi(round(N/2)) = 1/h;
%* Initialize loop and plot variables 
max_iter = 10;      % Particle should circle system
plot_iter = max_iter/100;          % Produce 10 curves
p_plot(:,1) = psi;     % Record initial condition
iplot = 1;

for iter=1:max_iter
	
  %* Compute new wave function using the Crank-Nicolson scheme
  psi = dCN*psi;  
  
  %* Periodically record values for plotting
  if( rem(iter,plot_iter) < 1 )   
    iplot = iplot+1;
    p_plot(:,iplot) = psi; 
    plot(x,p_plot(:,iplot));     % Display snap-shot of P(x)
    xlabel('x'); ylabel('P(x,t)');
    title(sprintf('Finished %g of %g iterations',iter,max_iter));
%      axis(axisV);
     drawnow;
  end

end         

			 