delta_t = 0.5;% time increment 
t_f = 100; % ending time 
t = 0:delta_t:t_f; %time array 
[~,N] = size(t); % N  = no of elements in t array = no of x values to be calculated
%----------- Start Verlet----------------%
x = zeros(1,N);% initialixing position array
v = zeros(1,N);%initializing velocity array
x(1) = 0.0; % initial position
v(1) = 1.0; % initial velocity
%acceleration a(n) = -x(n)
x0 = x(1)-delta_t*v(1)-(delta_t)^2*x(1)/2; % this is needed to find x_2. x0 here denotes x(t<0). 
x(2) = 2*x(1)-x0-(delta_t)^2*x(1); % writing this outside for loop because we need x0 value for only tis case.
for i=3:N
x(i) = 2*x(i-1)-x(i-2)-(delta_t)^2*x(i-1);
v(i-1) = (x(i)-x(i-2))/(2*delta_t); 
end 
x_Nplus1 = 2*x(N)-x(N-1)-(delta_t)^2*x(N);
v(N) = (x_Nplus1-x(N-1))/(2*delta_t); % since v(N) is not set by the for loop
figure 
plot(t, x, 'k*:')
grid on 
xlabel('t ')
ylabel('x_{Verlet}')
figure; plot(t, v, 'k*:')
grid on 
xlabel('t ')
ylabel('v_{Verlet}')
%--------------END Verlet------------%
%------------Start Rk4-----------%
xx = zeros(1,N);% initialixing position array
vv = zeros(1,N);%initializing velocity array
xx(1) = 0.0; % initial position
vv(1) = 1.0; % initial velocity
%acceleration a(n) = -x(n)
for i = 2:N
    Kx1=vv(i-1);
    Kv1=-xx(i-1);
    Kx2=vv(i-1)+delta_t*Kv1/2;
    Kv2=-(xx(i-1)+delta_t*Kx2/2);
    Kx3=vv(i-1)+delta_t*Kv2/2;
    Kv3=-(xx(i-1)+delta_t*Kx3/2);
    Kx4=vv(i-1)+delta_t*Kv3;
    Kv4=-(xx(i-1)+delta_t*Kx3);
    xx(i) = xx(i-1)+delta_t*(Kx1+2*Kx2+2*Kx3+Kx4)/6;
    vv(i) = vv(i-1)+delta_t*(Kv1+2*Kv2+2*Kv3+Kv4)/6;
    
end
figure 
plot(t, xx, 'b*:')
grid on 
xlabel('t ')
ylabel('x_{RK4}')
figure; plot(t, vv, 'b*:')
grid on 
xlabel('t ')
ylabel('v_{RK4}')
%------------END RK4-----------%
%-----------Computation of x_varlet(T) for different delta t values at t = 5-----%
delta_t = [0.5, 0.1, 0.05, 0.01, 0.005, 0.001];
x_varlet = zeros(1,length(delta_t));
T= 5;
for j = 1:length(delta_t)
    x1 = 0.0; % initial position
    v1 = 1.0; % initial velocity
    %acceleration a(n) = -x(n)
    x0 = x1-delta_t(j)*v1-(delta_t(j))^2*x1/2; % this is needed to find x_2. x0 here denotes x(t<0). 
    x2 = 2*x1-x0-(delta_t(j))^2*x(1); % writing this outside 2nd for loop because we need x0 value for only tis case.
    for i=3:T
        x3 = 2*x2-x2-(delta_t(j))^2*x2;
        x2 = x3;
    end  
    x_varlet(j)=x3;
end  
g1 = abs(sin(T) - x_varlet);
figure 
loglog(delta_t, g1, 'k*:')
grid on 
xlabel('log(delta t) ')
ylabel('log(g1)')
%----------------END---------------%
%------Computation of x_RK4(T) for different delta t values at t = 5-----%
delta_t = [0.5, 0.1, 0.05, 0.01, 0.005, 0.001];
x_RK4 = zeros(1,length(delta_t));
T= 5;
for j = 1:length(delta_t)
    xx1 = 0.0; % initial position
    vv1= 1.0; % initial velocity
    %acceleration a(n) = -x(n)
    for i = 2:T
        Kx1=vv1;
        Kv1=-xx1;
        Kx2=vv1+delta_t(j)*Kv1/2;
        Kv2=-(xx1+delta_t(j)*Kx2/2);
        Kx3=vv1+delta_t(j)*Kv2/2;
        Kv3=-(xx1+delta_t(j)*Kx3/2);
        Kx4=vv1+delta_t(j)*Kv3;
        Kv4=-(xx1+delta_t(j)*Kx3);
        xx2 = xx1+delta_t(j)*(Kx1+2*Kx2+2*Kx3+Kx4)/6;
        xx1 = xx2;
    end 
    x_RK4(j)=xx2;
end 
g2 = abs(sin(T) - x_RK4);
figure 
loglog(delta_t, g2, 'b*:')
grid on 
xlabel('log(delta t) ')
ylabel('log(g2)')