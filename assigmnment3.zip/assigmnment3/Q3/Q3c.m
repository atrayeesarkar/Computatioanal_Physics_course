z_f = 5;
delta_t = 1; %increment in z
z = 0:delta_t:z_f;
N = length(z);
x = zeros(1,N);% initialixing omega array
v = zeros(1,N); % initialixing omega_dashed array
a = zeros(1,N);%initializing omega_double_dashed array
x(1) = 0.5; % initial omega
v(1) = 0.0; % initial omega_dashed
a(1) = -1/4; %initial omega_double_dashed
%x''' = (1-6x)x'
%x' = v = Kx
%x''= v' = a = kv
%x'''= a' = (1-6x)x'=(1-6x)v= ka
for i = 2:2
    Ka1=(1-6*x(i-1))*v(i-1);
    Kv1=a(i-1);
    Kx1=v(i-1);
    Ka2=(1-6*(x(i-1)+delta_t/2*Kx1))*(v(i-1)+delta_t/2*Kv1);
    Kv2=a(i-1)+delta_t/2*Ka1;
    Kx2=v(i-1)+delta_t/2*Kv1;
    Ka3=(1-6*(x(i-1)+delta_t/2*Kx2))*(v(i-1)+delta_t/2*Kv2);
    Kv3=a(i-1)+delta_t/2*Ka2;
    Kx3=v(i-1)+delta_t/2*Kv2;
    Ka4=(1-6*(x(i-1)+delta_t*Kx3))*(v(i-1)+delta_t*Kv3);
    Kv4=a(i-1)+delta_t*Ka3;
    Kx4=v(i-1)+delta_t*Kv3;
    x(i) = x(i-1)+delta_t*(Kx1+2*Kx2+2*Kx3+Kx4)/6;
%   v(i) = v(i-1)+delta_t*(Kv1+2*Kv2+2*Kv3+Kv4)/6;
%   a(i) = a(i-1)+delta_t*(Ka1+2*Ka2+2*Ka3+Ka4)/6;
    
end
x_exact = 0.5*(sech(z/2)).^2;
figure 
hold on 
plot(z, x_exact, 'r.')
% legend('w_exact')
plot(z, x, 'k.')
% legend('w_rk4')
grid on 
xlabel('z ')
ylabel('w')
