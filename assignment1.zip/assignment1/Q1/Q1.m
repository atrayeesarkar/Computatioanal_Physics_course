
t = 2;
delta_t = zeros(1,5);
absolute_error = zeros(1,5);
j = 1;
for i = 0:5:20
    delta_t(j) = 10^(-i);
    x1_dash = dx(t);
    x1 = x(t);
    x2 = x(t+delta_t(j));
    absolute_error(j) = abs(x1_dash-(x2-x1)/delta_t(j));
    j = j+1;
end 
figure
loglog(delta_t,absolute_error,'k*')
xlabel('delta_t')
ylabel('absolute_error')
grid on
function y = dx(t)
y = -(1/(1+9*exp(-t))^2)*(-9*exp(-t));
end 
function y = x(t)
y = 1/(1+9*exp(-t));
end
