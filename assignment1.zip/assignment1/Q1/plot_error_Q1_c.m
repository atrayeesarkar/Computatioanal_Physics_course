Ax = load("error_Q1_c.txt");
figure
loglog(AX(:,1),AX(:,2),'b*')
grid on
xlabel('delta_t')
ylabel('absolute_error')