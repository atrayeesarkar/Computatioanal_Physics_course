import math	

def dx(t):
    return (1.0/(1+9*math.exp(-t))**2)*(-9*math.exp(-t))

def x(t):
    return 1.0/(1+9*math.exp(-t))

t = 2.0
f = open('error_Q1_py.txt','w')
for i in range(0,21,5):
    delta_t=pow(10,-i)
    x1_dash=dx(t)
    x1=x(t)
    x2=x(t+delta_t)
    error=abs(x1_dash-(x2-x1)/delta_t)
    f.write("%5.25f %5.25f\n" % (delta_t,error))
      
f.close()