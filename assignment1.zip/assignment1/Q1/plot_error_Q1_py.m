Ax = load("error_Q1_py.txt");
figure
loglog(AX(:,1),AX(:,2),'r*')
grid on
xlabel('delta_t')
ylabel('absolute_error')