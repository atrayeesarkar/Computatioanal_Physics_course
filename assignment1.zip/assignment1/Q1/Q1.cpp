#include <iostream>
#include <math.h>
#include <fstream>

double dx(double t);

double x(double t);

int main(){
double t=2;
double delta_t;
double error;
int j=1;
double x1;
double x1_dash;
double x2;

std::ofstream pfile("error_Q1_c.txt"); 


for(int i=0;i<21;){
    delta_t=pow(10,-i);
     x1_dash=dx(t);
     x1=x(t);
    x2=x(t+delta_t);
    error=abs(x1_dash-(x2-x1)/delta_t);
    pfile<<delta_t<<","<<error<<"\n";
    i = i+5;  
     
}

pfile.close();


return 0;}

double dx(double t){
    return  -pow(1/(1+9*exp(-t)),2)*(-9*exp(-t));
}

double x(double t){
    return 1/(1+9*exp(-t));
}