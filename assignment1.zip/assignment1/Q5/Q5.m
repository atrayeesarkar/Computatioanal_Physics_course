
%  PARAMETERS

max_iterations=50;  % max number of iterations
% numprint=30;  % how many numbers to print to the screen
r=[2.00,2.99];  % our choice of r
r1 = ones(51,1)*2.00;
r2 = ones(51,1)*2.99;
% INITIALIZATION
x=.01;  %our initial value
figure 
hold on
grid on
X = zeros(51,2);
X(1,:)= [0.1,0.1];
style = ['*';'o'];
plot(r(1),X(1,1),'k*')
plot(r(2),X(1,2),'ro')
% ITERATIONS
    for iter=1:max_iterations
        x=logistic_calculate(r(1),x);
        X(iter+1,1)=x;
         plot(r(1),x,'k*')
    end    %end of i iteration loop
   for iter=1:max_iterations
        x=logistic_calculate(r(2),x);
        X(iter+1,2)=x;
         plot(r(2),x, 'ro')
    end    %end of i iteration loop

plot(r1,X(:,1))
plot(r2,X(:,2))
xlabel('r');
ylabel('x');
% in matlab, functions are defined at the end of the script, not the beginning.
%t they can be declared externally too, which we'll see later.
function y=logistic_calculate(r,x)
	y=r*x*(1-x);
end
