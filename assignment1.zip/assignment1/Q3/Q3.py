import math
import numpy as np
import numpy.random as nr
import numpy.linalg as nl



a= []
b = []
a = nr.rand(3)
b= nr.rand(3)

def  GSO(a,b):
    d = (b-(np.dot(a,b)/nl.norm(a)**2)*a)
    c = nl.norm(b)/nl.norm(d)
    return d*c , a


v1,v2 = GSO(a,b)
print("\n v1:", v1,"\n")
print("v2:", v2,"\n")
