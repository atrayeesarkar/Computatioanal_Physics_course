a = rand(1,3);
b = rand(1,3);
figure
hold on
grid on
[v1,v2] = GSO(a,b);
disp(v1)
disp(v2)
function [v1,v2] = GSO(a,b)
    v1 = a;
    d = (b-(dot(a,b)/norm(a)^2).*a);
    c = norm(b)/norm(d);
    v2 = d.*c;
end 
 