#include <iostream>
#include <vector>
#include <random>
#include <math.h>
double dot(double a,double b);

void print(std::vector<double> a);

#define n 3 


int main(){
    std::vector<double> u1(n,1);  //initalize a vector to 1
	std::vector<double> u2(n,0);
    std::vector<double> v1(n,1);
    std::vector<double> v2(n,1);
	for(int i=0;i<n;i++){
		u1[i]=rand()/100000;
	}
    for(int i=0;i<n;i++){
		u2[i]=rand()/10000;
	}
     double s= 0;
    for(int i=0;i<n;i++){
        s = s+(u2[i]*u1[i]);
    }
   double  factor = (s/(pow(u1[1],2)+pow(u1[2],2)));
   for(int i=0;i<n;i++){
       v2[i]=factor*u1[i]; 
       v2[i] = u2[i]-v2[i];
   }
   double c = (pow(u2[1],2)+pow(u2[2],2))/(pow(v2[1],2)+pow(v2[2],2));

   for(int i=0;i<n;i++){
       v2[i]=c*v2[i]; 
       
   }
   v1 = u1;
   print(v1);
   std::cout<<"\n";
   print(v2);
   std::cout<<"\n";
   return 0;
}


void print(std::vector<double> a){
    std::cout<<"The vector elements are: ";

    for(int i = 0; i<a.size();i++){
        std::cout<< a.at(i)<<" ";
}

}



