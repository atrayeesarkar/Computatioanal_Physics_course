#include <iostream>
#include <fstream>
#include <math.h>
#include <cmath>

int main(){
    int x =1;
    int n = 100000;
    std::ofstream file("2a.txt");  
    for(int i=1;i<n;i++){
        x =  x*2;
        file<<x<<"\n"; 
        
    }
    x = 1;
    for(int i=1;i<32;i++){
        x =  x*2;
        if(signbit(x)!=0 || x ==0 ){
            std::cout<<"The highest power of 2 that can be represented as int is : "<<i-1<<"\n";
            
            break;}
        
    }
}