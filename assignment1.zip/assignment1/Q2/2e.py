x = 1
n = 1000

f = open('2e.txt','w')