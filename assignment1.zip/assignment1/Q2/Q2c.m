x = 1;
n = 10000;
for i = 1:n
    x = x*2;
    disp(x);
end
x = 1;

for i = 1:n
    x = x*2;
    if mod(x,2)~=0
        max_power =  i-1
          break;
    end 
   
end
