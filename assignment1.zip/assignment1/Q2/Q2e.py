import math
# # f = open('2e_int.txt','w')
x = 1
n = 2000

for i in range(1,n):
    x = x*2
    # f.write('%d \n' %(x))
    print('\n',x)


x = 1.0

for i in range(1,n):
    x = x*2.0
    print('\n', x)
x = 1.0

for i in range(1,n):
    x = x*2.0
    if(math.isinf(x)!=0):
        print("Then maximum power of 2 for float is:", i-1 )
        break