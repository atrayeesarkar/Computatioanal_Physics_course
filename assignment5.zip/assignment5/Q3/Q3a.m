D1 = load('data_1.csv');
D2 = load('data_2.csv');
D3 = load('data_3.csv');

tvals1 = D1(:,1);
tvals2 = D2(:,1);
tvals3 = D3(:,1);
xvals1 = D1(:,2);
xvals2 = D2(:,2);
xvals3 = D3(:,2);
vals = [5,0.5];
%minimize the squared error
bestfit1=fminsearch(@(x)lsquares(tvals1,xvals1,@fitfunction,x),vals);
bestfit2=fminsearch(@(x)lsquares(tvals2,xvals2,@fitfunction,x),vals);
bestfit3=fminsearch(@(x)lsquares(tvals3,xvals3,@fitfunction,x),vals);
figure %plot data and fit
hold on
plot(tvals1,xvals1,'o')
plot(tvals1,fitfunction(tvals1,bestfit1),'k','Linewidth',2)
plot(tvals2,xvals2,'*')
plot(tvals2,fitfunction(tvals2,bestfit2),'r','Linewidth',2)
plot(tvals3,xvals3,'.')
plot(tvals3,fitfunction(tvals3,bestfit3),'b','Linewidth',2)
function x=fitfunction(t,params)
    A=params(1);
    tau=params(2);
    x=A*exp(-t/tau);  %our fit function
end
function d=lsquares(tvals,xvals,fitfunction,params)  %computes the squared error between fit and data
    d=sum((xvals-fitfunction(tvals,params)).^2);
end