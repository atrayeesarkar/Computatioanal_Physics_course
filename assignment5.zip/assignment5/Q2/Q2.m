% using Newton's method.  Equations defined by function fnewt.
% since we want x*,y* such that F(x*,y*) = G(x*,y*) = 1, we will find roots
% of the functions f = F-1, g = G-1.

tol = 10^-10;
%* Set initial guess and parameters
x0 = input('Enter the initial guess (row vector): ');
x = x0;  % Copy initial guess
% a = input('Enter the parameter a: ');

%* Loop over desired number of steps 
nStep = 50;   % Number of iterations before stopping
for i=1:nStep
	
  %* Evaluate function f and its Jacobian matrix D
  [f,D] = fnewt(x);      % fnewt returns value of f and D
  %* Find dx by Gaussian elimination
  dx = f/D; 
  %* Update the estimate for the root  
  x1 = x - dx;              % Newton iteration for new x
%  sqrt((x1(1)-x(1))^2+(x1(2)-x(2))^2)
  if norm(x1-x)<tol % stop if tolerance is reached
      disp(x1)
      break
  end 
  x = x1;
end
[y,~] = fnewt(x); 
if abs(y(1)) < tol && abs(y(1)) < tol % to verify if we got the correct values of x and y
    disp('')
else 
    disp('error. choose a new initial guess')
end 
