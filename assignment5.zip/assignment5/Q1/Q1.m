% for multiple roots the user needs to run the code multiple times while
% adjusting the bisection interval.

tol = 10^(-6); %tolerance
global n
n = 0;
while n == 0 % to make it a loop if the user enters wrong interval
    lb = input('choose a value for lower bound of the interval: ');
    ub = input ('choose a value for upper bound of the interval: ');
    m = bisection_method(lb,ub,tol);
end
%define the function whose root(s) needs to be determined
function y = F(x)
    y = exp(x)-x^4;
end 

% define a function for bisection method
function  m = bisection_method( lb, ub, tol)
global n
% Evaluate upper and lower bounds of the bisection interval
y1 = F(lb);
y2 = F(ub);
i = 0; 
%  if signs are not different promt to choose upper and lower bounds again.
if y1 * y2 > 0
   disp('Root(s) not inside the interval. Choose upper and lower bound again');
   m = 'process terminated'; % have to assign m some value. else return won't work and the function willnot stop
   n = 0;% to make the code loop back to user input
   return
end 

% Work with the limits modifying them until you find
while (abs(ub - lb) >= tol)
    i = i + 1;
    % Find  new mean value 
    m = (ub + lb)/2;
    y3 = F(m);
    if y3 == 0 % y3 is the root
        fprintf('Root at x = %f \n\n', m);
        return
    
    % Update the limits
    elseif y1 * y3 > 0 % y3 and y1 are on the same side of the root
        lb = m; % replace lower bound by m
        y1 = y3;
    else
        ub = m;
    end
    n =1;
end 
% when difference < tollerance
fprintf('\n x = %f is the root with telerance = %f \n', m, tol);


end 