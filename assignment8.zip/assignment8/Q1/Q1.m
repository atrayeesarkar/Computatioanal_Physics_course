rng(2,'twister')
a = 1;% probability =a*1/x 
T =10;% interval upper bound
n = 10^5; % no of random nos
x = zeros(1,n); % initialiing
for i = 1:n
    x(i) = random_xinv(a,T); % calling function
end
figure
histogram(x,100,'Normalization','pdf') % ploting distribution
function x = random_xinv(a,T)
div = 0.1;
% min =1; % interval minimum
% interval = min-1/T; % since the probability is 1/x, we need to find uniform random no between (1/T,1)
% r =  interval*rand() +1/T; %uniform 
% x = a/r; % probability =a*1/x
 r = rand()*log(T);% so that x is between [0,T)
 x = exp(r/a);
end 
