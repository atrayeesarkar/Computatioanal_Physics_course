rng(2,'twister');

kT=1;
zeta=1;
m=1;
dt=0.001;
nstep=10000;
nrun=10;


xvals=zeros(1,nstep);
xsqvals=zeros(1,nstep);
vsqvals=zeros(1,nstep);
tvals=zeros(1,nstep);

d